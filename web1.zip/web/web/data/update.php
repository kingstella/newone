<?php
/**
*接收客户端提交的新用户信息，保存入数据库，返回 {"msg": "succ", "uid": 3} 或 {"msg":"err", "sql":"INSERT...."}
*/
header('Content-Type: application/json;charset=UTF-8');

//接收并处理客户端提交的请求数据
$name = $_REQUEST['name'];
$age = $_REQUEST['age'];
$id= $_REQUEST['id'];

include('config.php');
$conn = mysqli_connect($db_url, $db_user, $db_pwd, $db_name, $db_port);

//提交SQL
$sql = "SET NAMES UTF8";
mysqli_query($conn,$sql);

$sql = "update stu set name='$name',age='$age' where id='$id'";
$result=mysqli_query($conn,$sql);

$output=[];
if($result){
    $output['msg'] = 'succ';
}else{
    $output['msg'] = 'err';
}


echo json_encode($output);
