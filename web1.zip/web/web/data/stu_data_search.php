<?php
header('Content-Type:application/json;charset=UTF-8');

$name=$_REQUEST['name'];
$age=$_REQUEST['age'];

include('config.php');
$conn = mysqli_connect($db_url, $db_user, $db_pwd, $db_name, $db_port);

$sql= "SET NAMES UTF8";
mysqli_query($conn,$sql);

$sql="SELECT id,name,age FROM stu ";
$result = mysqli_query($conn,$sql);


$list = mysqli_fetch_all($result, MYSQLI_ASSOC);


echo json_encode($list);