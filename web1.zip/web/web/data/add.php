<?php

header('Content-Type: application/json;charset=UTF-8');


$name = $_REQUEST['name'];
$age = $_REQUEST['age'];

include('config.php');
$conn = mysqli_connect($db_url, $db_user, $db_pwd, $db_name, $db_port);


$sql = "SET NAMES UTF8";
mysqli_query($conn,$sql);
$sql = "INSERT INTO stu VALUES(NULL,'$name','$age')";
$result = mysqli_query($conn,$sql);

$output=[];
if($result){
    $output['msg'] = 'succ';
}else{
    $output['msg'] = 'err';
}


echo json_encode($output);


