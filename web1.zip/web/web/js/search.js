/**
 * Created by Administrator on 2017/3/24.
 */

$(function() {
    $.ajax({
        type: 'get',
        url: 'data/stu_data_search.php',
        data:{'name':'','age':''},
        success: function (data) {
            var html = '';
            $.each(data, function (i, v) {
                html +=
                    `<form id="sf1">
                    <tr>
                        <td class="sf1td"><input id="aid" value="${v.id}"></td>
                        <td class="sf1td"><input name="name" id="aname" value="${v.name}"></td>
                        <td class="sf1td"><input name="age" id="aage" value="${v.age}"></td>
                        <td class="sf1td"><a href="#id=${v.id}" class="edit">编辑</a> <a href="#id=${v.id}" id="delete">删除</a></td>
                    </tr>
                    </form>
                `
            });
            $('#s2t').html(html);
}
    });

});

