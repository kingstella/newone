
$('#s2t').on('click','.edit',function(){
    $('#box5').toggle();
});


function getUrlParam(id) {
    var reg = new RegExp("(^|&)" + id + "=([^&]*)(&|$)");
    var r = window.location.hash.substr(1).match(reg);
    if (r != null){
        return unescape(r[2]);}
    return null;
}


 $('.edit').click(function(){

     var id=getUrlParam('id');
     var data=$.param({'id':id})+'&'+$('#form2').serialize();

     //异步POST请求，提交数据
    $.ajax({
        type:'POST',
        url: 'data/update.php',
        data:data,
        success: function (result) {
            console.log(result);
            window.location.href='index.html';
        }
    })
});
