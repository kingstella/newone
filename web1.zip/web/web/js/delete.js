
$('#s2t').on('click','#delete',function(){
    $('#box4').toggle();
});

function getUrlParam(id) {
    var reg = new RegExp("(^|&)" + id + "=([^&]*)(&|$)");
    var r = window.location.hash.substr(1).match(reg);
    if (r != null){
        return unescape(r[2]);}
    return null;
}

$('#dyes').click(function(){

    var id=getUrlParam('id');
    var data=$.param({'id':id});
    //发起异步请求
    $.ajax({
        type: 'POST',
        url: 'data/delete.php',
        data:data,
        success: function(){

            window.location.href='index.html';
        }
    });

});

$('#dno').click(function(){
    $('#box4').toggle();
})