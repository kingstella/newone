/**
 * Created by Administrator on 2017/3/24.
 */

$('#enter').click(function(){
    var data=$('#add').serialize();


//异步提交请求数据
$.ajax({
    type: 'POST',
    url: 'data/add.php',
    data: data,
    success: function(result){
        console.log(result);
    }
   });
});